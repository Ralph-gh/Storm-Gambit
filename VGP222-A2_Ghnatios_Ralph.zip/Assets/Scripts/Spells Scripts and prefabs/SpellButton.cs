using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellButton : MonoBehaviour
{
   /* public SpellData spellData;
    public Image iconImage;
    public Button clickButton;

    private void Start()
    {
        iconImage.sprite = spellData.icon;
        clickButton.onClick.AddListener(OpenSpellUI);
    }

    void OpenSpellUI()
    {
        Debug.Log("Opening UI for spell: " + spellData.spellName);
        Instantiate(spellData.spellUI, GameObject.Find("Canvas").transform);
    }*/
}

